import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import axios from 'axios';
import { axiosDefaults } from './axios';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const theme = createTheme();

export default function UserDetails() {
  const [user, setUser] = useState([]);
  const [companies, setCompanies] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('/Users/10', axiosDefaults).then((request) => setUser(request.data));
  }, []);
  useEffect(() => {
    axios.get('/Companies', axiosDefaults).then((request) => setCompanies(request.data));
  }, []);
  return (
    <div>
      <Container component='main'>
        <CssBaseline />
        <Box
          sx={{
            marginTop: 3,
          }}
        >
          <Typography component='h1' variant='h5' sx={{ fontSize: 30, paddingTop: 10, paddingBottom: 10, textAlign: 'center' }}>
            User details
          </Typography>
          <Grid container columns={{ xs: 2, sm: 3 }}>
            <Grid item xs={0.5}>
              <Button
                onClick={() => axios.delete('http://localhost:5017/api/Users/10').then(() => navigate('/users'))}
                sx={{ marginBottom: 2 }}
                variant='outlined'
              >
                Delete
              </Button>
            </Grid>
            <Grid item xs={0.4}>
              <Button href='/user/1/edit' sx={{ marginBottom: 2 }} variant='outlined'>
                Edit
              </Button>
            </Grid>
            <Grid item xs={0.5}>
              <Button
                onClick={() =>
                  axios.put('http://localhost:5017/api/Users/3', {
                    active: false,
                    id: user.id,
                    cnp: user.cnp,
                    icnumber: user.icnumber,
                    mail: user.mail,
                    profileImage: user.profileImage,
                    companyId: user.companyId,
                    name: user.name,
                    password: user.password,
                    role: user.role,
                    username: user.username,
                  })
                }
                sx={{ marginBottom: 2 }}
                variant='outlined'
              >
                Deactivate
              </Button>
            </Grid>
          </Grid>

          <Grid container columns={{ xs: 1, sm: 1, md: 2, lg: 5 }}>
            <Grid item xs={0.7}>
              <p>Username</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>{user.username}</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Name</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>{user.name}</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Mail</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>{user.mail}</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Company</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>{companies.find((c) => c.id === user.companyId)?.name}</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Role</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>{user.role}</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Active</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>{String(user.active)}</strong>
              </p>
            </Grid>
            <Grid item xs={3}>
              <img style={{ height: 300, position: 'absolute', top: 300, right: 150 }} src={user.profileImage} />
            </Grid>
          </Grid>
        </Box>
      </Container>
    </div>
  );
}
