import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import axios from 'axios';
import { axiosDefaults } from './axios';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const theme = createTheme();

export default function CompanyEditDetails() {
  const [company, setCompany] = useState([]);
  const [nameInput, setNameInput] = useState(null);
  const [cuiInput, setCuiInput] = useState(null);
  const [regNoInput, setRegNoInput] = useState(null);
  const [addressInput, setAddressInput] = useState(null);
  const [phoneInput, setPhoneInput] = useState(null);
  const [mailInput, setMailInput] = useState(null);
  const [ibanInput, setIbanInput] = useState(null);
  const [bankNameInput, setBankNameInput] = React.useState(null);
  const [capitalAmtInput, setCapitalAmtInput] = React.useState(null);
  const [pictureInput, setPictureInput] = React.useState(null);
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
  };

  useEffect(() => {
    axios.get('/Companies/1', axiosDefaults).then((request) => {
      setCompany(request.data);
      setNameInput(request.data.name);
      setCuiInput(request.data.cui);
      setRegNoInput(request.data.regNo);
      setAddressInput(request.data.address);
      setPhoneInput(request.data.phone);
      setMailInput(request.data.mail);
      setIbanInput(request.data.iban);
      setBankNameInput(request.data.bankName);
      setCapitalAmtInput(request.data.capitalAmt);
      setPictureInput(request.data.profileImage);
    });
  }, []);

  return (
    <div>
      <Container component='main'>
        <CssBaseline />
        <Box
          onSubmit={handleSubmit}
          sx={{
            marginTop: 3,
          }}
        >
          <Typography component='h1' variant='h5' sx={{ fontSize: 30, paddingTop: 10, paddingBottom: 10, textAlign: 'center' }}>
            Edit company
          </Typography>

          <Grid container columns={{ xs: 1, sm: 1, md: 2, lg: 5 }}>
            <Grid item xs={0.7}>
              <p>Registration no.*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={regNoInput}
                onChange={(event) => setRegNoInput(event.target.value)}
                style={{ top: 5 }}
                required
                id='standard-required'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>Name*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={nameInput}
                onChange={(event) => setNameInput(event.target.value)}
                style={{ top: 5 }}
                id='standard-optional'
                defaultValue='Hello World'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>Address</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={addressInput}
                onChange={(event) => setAddressInput(event.target.value)}
                style={{ top: 5 }}
                id='standard-required'
                defaultValue='Hello World'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>Phone*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={phoneInput}
                onChange={(event) => setPhoneInput(event.target.value)}
                style={{ top: 5 }}
                required
                id='standard-required'
                defaultValue='Hello World'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>Mail*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={mailInput}
                onChange={(event) => setMailInput(event.target.value)}
                style={{ top: 5 }}
                required
                id='standard-required'
                defaultValue='Hello World'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>IBAN*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={ibanInput}
                onChange={(event) => setIbanInput(event.target.value)}
                style={{ top: 5 }}
                id='standard-optional'
                defaultValue='Hello World'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>CUI*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={cuiInput}
                onChange={(event) => setCuiInput(event.target.value)}
                style={{ top: 5 }}
                id='standard-optional'
                defaultValue='Hello World'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>Bank name</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={bankNameInput}
                onChange={(event) => setBankNameInput(event.target.value)}
                style={{ top: 5 }}
                id='standard-optional'
                defaultValue='Hello World'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>Capital amount</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField
                value={capitalAmtInput}
                onChange={(event) => setCapitalAmtInput(event.target.value)}
                style={{ top: 5 }}
                id='standard-optional'
                defaultValue='Hello World'
                variant='standard'
              />
            </Grid>
            <Grid item xs={0.7}>
              <p>Picture</p>
            </Grid>
            <Grid item xs={1.5}>
              <Button style={{ top: 5 }} component='label' variant='outlined' sx={{ marginRight: '1rem' }}>
                Upload
                <input type='file' accept='.jpg' hidden />
              </Button>
              <Box></Box>
            </Grid>
          </Grid>
          <Button
            onClick={() =>
              axios
                .put('http://localhost:5017/api/Companies/1', {
                  name: nameInput,
                  id: company.id,
                  cui: cuiInput,
                  regNo: regNoInput,
                  address: addressInput,
                  profileImage: pictureInput,
                  phone: phoneInput,
                  mail: mailInput,
                  iban: ibanInput,
                  bankName: bankNameInput,
                  capitalAmt: capitalAmtInput,
                })
                .then(() => navigate('/company/1'))
            }
            style={{ top: 5 }}
            component='label'
            variant='outlined'
            sx={{ marginLeft: '25rem', marginTop: '1rem', marginBottom: '2rem' }}
          >
            Save
          </Button>
        </Box>
      </Container>
    </div>
  );
}
