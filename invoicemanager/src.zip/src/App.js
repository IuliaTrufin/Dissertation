import './index.css';
import { useEffect, useState } from 'react';
import AccountMenuIntro from './MenuIntro';
import AccountMenuLogged from './MenuLogged';
import MultiAxisLine from './HomeLogged';
import Home from './Home';
import SignIn from './SignIn';
import { Routes, Route, BrowserRouter, useNavigate } from 'react-router-dom';
import InvoiceProfile from './InvoiceProfile';
import UsersDataGrid from './Users';
import UserDetails from './UserDetails';
import UserEditDetails from './UserEdit';
import UserAddDetails from './UserAdd';
import CompaniesDataGrid from './Companies';
import CompanyDetails from './CompanyDetails';
import CompanyEditDetails from './CompanyEdit';
import CompanyAddDetails from './CompanyAdd';
import ProductsDataGrid from './Products';
import ProductDetails from './ProductDetails';
import ProductEditDetails from './ProductEdit';
import ProductAddDetails from './ProductAdd';
import InvoicesDataGrid from './Invoices';
import InvoiceDetails from './InvoiceDetails';
import InvoiceEditDetails from './InvoiceEdit';
import InvoiceAddDetails from './InvoiceAdd';
import ProfileDetails from './Profile';
import axios from 'axios';
import { axiosDefaults } from './axios';

function App() {
  const [user, setUser] = useState(null);
  const handleUserLoggin = () => {
    if (user) {
      setUser(null);
    } else {
      setUser({ username: 'admin', userId: 1 });
    }
  };

  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('/Users', axiosDefaults).then((request) => setUsers(request.data));
  }, []);

  let navigate = useNavigate();

  const routeChange = (path) => {
    navigate(path);
  };

  const handleSignin = (user) => {
    setUser(user);
    routeChange('/home');
    // Do navigsation to homepage
  };

  const handleSignout = (user) => {
    setUser(null);
    routeChange('/home');
    // Do navigsation to homepage
  };

  // fetch('https://localhost:44483/user').then((response) => console.log(response.json()));
  return (
    <>
      {/* <p>{users.map((x) => x.id).join(',')}</p>
      <button onClick={() => axios.get('/Users', axiosDefaults).then((request) => setUsers(request.data))}></button> */}
      {!!user ? <AccountMenuLogged setUser={setUser} /> : <AccountMenuIntro />}
      {/* <AccountMenu user={user} handleUserLoggin={handleUserLoggin} /> */}
      {/* <AccountMenu /> */}
      <Routes>
        <Route element={<Home />} path='/home' />
        <Route element={<Home />} exact path='/' />
        <Route element={<UsersDataGrid />} path='users' />
        <Route element={<UserDetails />} path='user/1' />
        <Route element={<UserEditDetails />} path='user/1/edit' />
        <Route element={<UserAddDetails />} path='user/add' />
        <Route element={<CompaniesDataGrid />} path='companies' />
        <Route element={<CompanyDetails />} path='company/1' />
        <Route element={<CompanyEditDetails />} path='company/1/edit' />
        <Route element={<CompanyAddDetails />} path='company/add' />
        <Route element={<ProductsDataGrid />} path='products' />
        <Route element={<ProductDetails />} path='product/1' />
        <Route element={<ProductEditDetails />} path='product/1/edit' />
        <Route element={<ProductAddDetails />} path='product/add' />
        <Route element={<InvoicesDataGrid />} path='invoices' />
        <Route element={<InvoiceDetails />} path='invoice/1' />
        <Route element={<InvoiceEditDetails />} path='invoice/1/edit' />
        <Route element={<InvoiceAddDetails />} path='invoice/add' />
        <Route element={<ProfileDetails />} path='myprofile' />
        {/* <Route element={<News />} path='news' /> */}
        <Route element={<SignIn handleSignin={handleSignin} />} path='signin' />
        <Route exact element={<InvoiceProfile user={user} />} path='/invoice/:id' />
      </Routes>
    </>
  );
}

export default App;
