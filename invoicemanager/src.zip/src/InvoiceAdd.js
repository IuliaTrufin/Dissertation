import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

const theme = createTheme();

export default function InvoiceAddDetails() {
  return (
    <div>
      <Container component='main'>
        <CssBaseline />
        <Box
          sx={{
            marginTop: 3,
          }}
        >
          <Typography component='h1' variant='h5' sx={{ fontSize: 30, paddingTop: 10, paddingBottom: 10, textAlign: 'center' }}>
            Add invoice
          </Typography>

          <Grid container columns={{ xs: 1, sm: 1, md: 2, lg: 5 }}>
            <Grid item xs={0.7}>
              <p>Invoice no.*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} required id='standard-required' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Serial no.*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-optional' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Due date*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-required' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Issuer*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} required id='standard-required' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Billed to*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} required id='standard-required' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Paid*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-optional' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Total price*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-optional' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Created at</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-optional' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Type</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-optional' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Invoice PDF</p>
            </Grid>
            <Grid item xs={1.5}>
              <Button style={{ top: 5 }} component='label' variant='outlined' sx={{ marginRight: '1rem' }}>
                Upload
                <input type='file' accept='.pdf, .jpg, .jpeg, .png' hidden />
              </Button>
              <Box></Box>
            </Grid>
          </Grid>
          <Button
            style={{ top: 5 }}
            component='label'
            variant='outlined'
            sx={{ marginLeft: '25rem', marginTop: '1rem', marginBottom: '2rem' }}
          >
            Save
          </Button>
        </Box>
      </Container>
    </div>
  );
}
