export const axiosDefaults = { baseURL: 'http://localhost:5017/api', headers: { 'Access-Control-Allow-Origin': '*' } };
