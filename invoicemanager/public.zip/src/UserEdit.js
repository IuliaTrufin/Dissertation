import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

const theme = createTheme();

export default function UserEditDetails() {
  const [role, setRole] = React.useState('');
  const [active, setActive] = React.useState('');

  const handleChangeRole = (event) => {
    setRole(event.target.value);
  };
  const handleChangeActive = (event) => {
    setActive(event.target.value);
  };
  return (
    <div>
      <Container component='main'>
        <CssBaseline />
        <Box
          sx={{
            marginTop: 3,
          }}
        >
          <Typography component='h1' variant='h5' sx={{ fontSize: 30, paddingTop: 10, paddingBottom: 10, textAlign: 'center' }}>
            Edit user
          </Typography>

          <Grid container columns={{ xs: 1, sm: 1, md: 2, lg: 5 }}>
            <Grid item xs={0.7}>
              <p>Username*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} required id='standard-required' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Name*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-optional' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Mail</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-required' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Company*</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} required id='standard-required' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>CNP</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} required id='standard-required' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>IC no.</p>
            </Grid>
            <Grid item xs={1.5}>
              <TextField style={{ top: 5 }} id='standard-optional' defaultValue='Hello World' variant='standard' />
            </Grid>
            <Grid item xs={0.7}>
              <p>Role*</p>
            </Grid>
            <Grid item xs={1.5}>
              <Select style={{ top: 5 }} labelId='role-select' label='Role' value={role} onChange={handleChangeRole} variant='standard'>
                <MenuItem value={'superAdmin'}>Super Admin</MenuItem>
                <MenuItem value={'admin'}>Admin</MenuItem>
                <MenuItem value={'user'}>User</MenuItem>
              </Select>
            </Grid>
            <Grid item xs={0.7}>
              <p>Active*</p>
            </Grid>
            <Grid item xs={1.5}>
              <Select
                style={{ top: 5 }}
                labelId='active-select'
                label='Active'
                value={active}
                onChange={handleChangeActive}
                variant='standard'
              >
                <MenuItem value={'active'}>Active</MenuItem>
                <MenuItem value={'inactive'}>Inactive</MenuItem>
              </Select>
            </Grid>

            <Grid item xs={0.7}>
              <p>Picture</p>
            </Grid>
            <Grid item xs={1.5}>
              <Button style={{ top: 5 }} component='label' variant='outlined' sx={{ marginRight: '1rem' }}>
                Upload
                <input type='file' accept='.jpg' hidden />
              </Button>
              <Box></Box>
            </Grid>
          </Grid>
          <Button
            style={{ top: 5 }}
            component='label'
            variant='outlined'
            sx={{ marginLeft: '25rem', marginTop: '1rem', marginBottom: '2rem' }}
          >
            Save
          </Button>
        </Box>
      </Container>
    </div>
  );
}
