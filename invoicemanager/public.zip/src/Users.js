import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Chart from 'chart.js/auto';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { saveAs } from 'file-saver';
import { CSVLink } from 'react-csv';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const columns = [
  {
    field: 'username',
    headerName: 'Username',
    width: 150,
    editable: true,
    renderCell: (params) => (
      <Link href='/user/1' underline='hover'>
        Details
      </Link>
    ),
  },
  {
    field: 'name',
    headerName: 'Full name',
    width: 150,
    editable: true,
  },
  {
    field: 'company',
    headerName: 'Company',
    width: 110,
    editable: true,
  },
  {
    field: 'active',
    headerName: 'Active',
    width: 160,
    editable: true,
  },
];

const rows = [
  { id: 1, lastName: 'Snow', firstName: 'Jon', age: 35 },
  { id: 2, lastName: 'Lannister', firstName: 'Cersei', age: 42 },
  { id: 3, lastName: 'Lannister', firstName: 'Jaime', age: 45 },
  { id: 4, lastName: 'Stark', firstName: 'Arya', age: 16 },
  { id: 5, lastName: 'Targaryen', firstName: 'Daenerys', age: null },
  { id: 6, lastName: 'Melisandre', firstName: null, age: 150 },
  { id: 7, lastName: 'Clifford', firstName: 'Ferrara', age: 44 },
  { id: 8, lastName: 'Frances', firstName: 'Rossini', age: 36 },
  { id: 9, lastName: 'Roxie', firstName: 'Harvey', age: 65 },
  { id: 10, lastName: 'Roxie', firstName: 'Harvey', age: 65 },
];

const dataUsersPerCompany = {
  labels: ['Company1', 'Company2', '3', '4', '5', '6'],
  datasets: [
    {
      label: 'Number of active users',
      data: [12, 19, 3, 5, 2, 3],
      // fill: false,
      backgroundColor: 'rgb(255, 99, 132)',
      // borderColor: 'rgba(255, 99, 132, 0.4)',
      // yAxisID: 'y-axis-1',
    },
    {
      label: 'Number of inactive users',
      data: [1, 2, 1, 1, 2, 2],
      // fill: false,
      backgroundColor: 'rgb(54, 162, 235)',
      // borderColor: 'rgba(54, 162, 235, 0.4)',
      // yAxisID: 'y-axis-2',
    },
  ],
};
export const options = {
  responsive: true,
  plugins: {
    legend: {
      position: 'top',
    },
    title: {
      display: true,
      text: 'Users per companies',
    },
  },
};

function saveCanvas() {
  //save to png
  const canvasSave = document.getElementById('userChart');
  canvasSave.toBlob(function (blob) {
    saveAs(blob, 'testing.png');
  });
}

export default function UsersDataGrid() {
  const data = React.useMemo(() => {
    return rows.map((d) => Object.values(d));
  }, []);
  return (
    <div>
      <Container component='main'>
        <CssBaseline />
        <Box
          sx={{
            marginTop: 3,
          }}
        >
          <Typography component='h1' variant='h5' sx={{ fontSize: 30, paddingTop: 10, paddingBottom: 10, textAlign: 'center' }}>
            Users
          </Typography>
          <Grid container columns={{ xs: 2, sm: 3 }}></Grid>

          <Grid container columns={{ xs: 1, sm: 1, md: 5, lg: 5 }}>
            <Grid item xs={1}>
              <Button onClick={saveCanvas} sx={{ marginBottom: 2 }} variant='outlined'>
                Export chart
              </Button>
            </Grid>
            <Grid item xs={5} style={{ marginBottom: 100 }}>
              <Bar id='userChart' options={options} data={dataUsersPerCompany} />
            </Grid>
            <Grid item xs={0.5}>
              <CSVLink data={data} style={{ textDecoration: 'none' }} underline='hover' filename='UserData.csv'>
                <Button sx={{ marginBottom: 2 }} variant='outlined'>
                  Export
                </Button>
              </CSVLink>
            </Grid>
            <Grid item xs={0.4}>
              <Button href='/user/add' sx={{ marginBottom: 2 }} variant='outlined'>
                Add
              </Button>
            </Grid>
            <Grid item xs={5}>
              <DataGrid
                style={{ height: 650 }}
                rows={rows}
                columns={columns}
                pageSize={10}
                rowsPerPageOptions={[10]}
                disableSelectionOnClick
              />
            </Grid>
          </Grid>
        </Box>
      </Container>
    </div>
  );
}
