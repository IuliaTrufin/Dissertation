import * as React from 'react';
import AccountMenu from './MenuLogged';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';

const theme = createTheme();

export default function CompanyDetails() {
  return (
    <div>
      <Container component='main'>
        <CssBaseline />
        <Box
          sx={{
            marginTop: 3,
          }}
        >
          <Typography component='h1' variant='h5' sx={{ fontSize: 30, paddingTop: 10, paddingBottom: 10, textAlign: 'center' }}>
            Company details
          </Typography>
          <Grid container columns={{ xs: 2, sm: 3 }}>
            <Grid item xs={0.5}>
              <Button sx={{ marginBottom: 2 }} variant='outlined'>
                Delete
              </Button>
            </Grid>
            <Grid item xs={0.4}>
              <Button href='/company/1/edit' sx={{ marginBottom: 2 }} variant='outlined'>
                Edit
              </Button>
            </Grid>
          </Grid>

          <Grid container columns={{ xs: 1, sm: 1, md: 2, lg: 5 }}>
            <Grid item xs={0.7}>
              <p>Registration no.</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Name</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Address</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Phone</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Mail</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>IBAN</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={3}>
              <img
                style={{ height: 300, position: 'absolute', top: 300, right: 150 }}
                src={`https://images.unsplash.com/photo-1567306301408-9b74779a11af?w=164&h=164&fit=crop&auto=format`}
              />
            </Grid>
          </Grid>
        </Box>
      </Container>
    </div>
  );
}
