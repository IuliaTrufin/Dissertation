import './index.css';
import { useState } from 'react';
import AccountMenu from './MenuLogged';
import MultiAxisLine from './HomeLogged';
import Home from './Home';
import SignIn from './SignIn';
import { Router, Routes, Route, BrowserRouter } from 'react-router-dom';
import InvoiceProfile from './InvoiceProfile';
import UsersDataGrid from './Users';
import UserDetails from './UserDetails';
import UserEditDetails from './UserEdit';
import UserAddDetails from './UserAdd';
import CompaniesDataGrid from './Companies';
import CompanyDetails from './CompanyDetails';
import CompanyEditDetails from './CompanyEdit';
import CompanyAddDetails from './CompanyAdd';
import ProductsDataGrid from './Products';
import ProductDetails from './ProductDetails';
import ProductEditDetails from './ProductEdit';
import ProductAddDetails from './ProductAdd';
import InvoicesDataGrid from './Invoices';
import InvoiceDetails from './InvoiceDetails';
import InvoiceEditDetails from './InvoiceEdit';
import InvoiceAddDetails from './InvoiceAdd';
import ProfileDetails from './Profile';

function App() {
  const [user, setUser] = useState(null);
  const handleUserLoggin = () => {
    if (user) {
      setUser(null);
    } else {
      setUser({ username: 'admin', userId: 1 });
    }
  };

  return (
    <BrowserRouter>
      {/* <AccountMenu user={user} handleUserLoggin={handleUserLoggin} /> */}
      <AccountMenu />
      <Routes>
        <Route element={<Home />} path='/home' />
        <Route element={<Home />} exact path='/' />
        <Route element={<UsersDataGrid />} path='users' />
        <Route element={<UserDetails />} path='user/1' />
        <Route element={<UserEditDetails />} path='user/1/edit' />
        <Route element={<UserAddDetails />} path='user/add' />
        <Route element={<CompaniesDataGrid />} path='companies' />
        <Route element={<CompanyDetails />} path='company/1' />
        <Route element={<CompanyEditDetails />} path='company/1/edit' />
        <Route element={<CompanyAddDetails />} path='company/add' />
        <Route element={<ProductsDataGrid />} path='products' />
        <Route element={<ProductDetails />} path='product/1' />
        <Route element={<ProductEditDetails />} path='product/1/edit' />
        <Route element={<ProductAddDetails />} path='product/add' />
        <Route element={<InvoicesDataGrid />} path='invoices' />
        <Route element={<InvoiceDetails />} path='invoice/1' />
        <Route element={<InvoiceEditDetails />} path='invoice/1/edit' />
        <Route element={<InvoiceAddDetails />} path='invoice/add' />
        <Route element={<ProfileDetails />} path='myprofile' />
        {/* <Route element={<News />} path='news' /> */}
        <Route element={<SignIn />} path='signin' />
        <Route exact element={<InvoiceProfile user={user} />} path='/invoice/:id' />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
