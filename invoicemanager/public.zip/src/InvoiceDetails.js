import * as React from 'react';
import AccountMenu from './MenuLogged';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import { useState, useRef } from 'react';
import invoice1 from './Invoice1.pdf';
import ReactToPrint, { PrintContextConsumer } from 'react-to-print';

const theme = createTheme();

export default function InvoiceDetails() {
  const [viewed, setViewed] = useState('No');
  return (
    <div>
      <Container component='main'>
        <CssBaseline />
        <Box
          sx={{
            marginTop: 3,
          }}
        >
          <Typography component='h1' variant='h5' sx={{ fontSize: 30, paddingTop: 10, paddingBottom: 10, textAlign: 'center' }}>
            Invoice details
          </Typography>
          <Grid container columns={{ xs: 2, sm: 3 }}>
            <Grid item xs={0.5}>
              <Button sx={{ marginBottom: 2 }} variant='outlined'>
                Delete
              </Button>
            </Grid>
            <Grid item xs={0.5}>
              <Button href='/invoice/1/edit' sx={{ marginBottom: 2 }} variant='outlined'>
                Edit
              </Button>
            </Grid>
          </Grid>

          <Grid container columns={{ xs: 1, sm: 1, md: 2, lg: 5 }}>
            <Grid item xs={0.7}>
              <p>Invoice no.</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Serial no.</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Due date</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Issuer</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Billed to</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Paid</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Total price</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Viewed</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>{viewed}</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Created at</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={0.7}>
              <p>Type</p>
            </Grid>
            <Grid item xs={1.5}>
              <p>
                <strong>something here</strong>
              </p>
            </Grid>
            <Grid item xs={3}>
              {/* <img
                style={{ width: 1000, height: 400, marginTop: 50 }}
                src={`https://images.unsplash.com/photo-1567306301408-9b74779a11af?w=164&h=164&fit=crop&auto=format`}
              /> */}
              <object
                style={{ width: 1000, height: 1000, marginTop: 50 }}
                data={invoice1}
                type='application/pdf'
                width='100%'
                height='100%'
              />
            </Grid>
          </Grid>
        </Box>
      </Container>
    </div>
  );
}
